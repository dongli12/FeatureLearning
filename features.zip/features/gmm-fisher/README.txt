The original GMM and Fisher vector computation code by Jorge Sanchez was released as a part of the 
encoding evaluation toolkit by Ken Chatfield:
http://www.robots.ox.ac.uk/~vgg/software/enceval_toolkit/

It was later modified by Karen Simonyan and included into the face descriptor computation package: 
http://www.robots.ox.ac.uk/~vgg/software/face_desc/
