%  Copyright (c) 2014, Karen Simonyan
%  All rights reserved.
%  This code is made available under the terms of the BSD license (see COPYING file).

% configuration file for feature computation
function conf = feat_config(varargin)

conf = [];

% PCA-SIFT dimensionality
conf.descDim = 64;

% GMM size
conf.vocSize = 128;

prms = struct;

% experiment name
prms.expName = ['SIFT_PCA' num2str(conf.descDim) '_GMM' num2str(conf.vocSize)];
conf.expName = prms.expName;

% image set name
prms.setName = 'CIFAR10';
conf.setName = prms.setName;

prms = vl_argparse(prms, varargin);

conf.rngSeed = 6756;
rng(conf.rngSeed);

familyDir = '../data/';

conf.database.setDir = sprintf('%s/%s/', familyDir, prms.setName);
% conf.database.sharedDir = sprintf('%s/shared/', familyDir);

conf.database.dbPath = sprintf('%s/images.mat',conf.database.setDir);

% conf.database.imDir = sprintf('%s/images/', conf.database.setDir);
conf.database.imDir = sprintf('%s/images/',conf.database.setDir);

% set to true to compute FV on flipped images
conf.compMirrorFeat = false;
% conf.compMirrorFeat = true;

conf.exp.rootDir = sprintf('%s/%s/', conf.database.setDir, prms.expName);
conf.exp.cbookDir = sprintf('%s/codebooks/', conf.exp.rootDir);

% face descriptor
conf.faceDescriptor = face_desc.lib.face_descriptor.poolFV();

end
