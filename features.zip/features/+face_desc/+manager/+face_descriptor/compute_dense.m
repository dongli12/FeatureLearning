%  Copyright (c) 2014, Karen Simonyan
%  All rights reserved.
%  This code is made available under the terms of the BSD license (see COPYING file).

conf = face_desc.config.feat_config();

fprintf('Computing SIFT\n');

descDir = sprintf('%s/', conf.exp.cbookDir);
descPath = sprintf('%s/sift.mat', descDir);

% check if already computed
if ~exist(descPath, 'file')

mkdir(descDir);

% number of features for PCA/GMM learning
totalFeatLimit = 1e5;
load(conf.database.dbPath);
numImg = 1e3;
imgFeatLimit = ceil(totalFeatLimit / numImg);
featImg = cell(1, 1);

for i = 1:numImg
    
    fprintf('Extract SIFT: %d/%d\n', i, numImg);
    rng(conf.rngSeed);
    img =imread([conf.database.imDir images{i}]);
    if size(img,3) == 3
        img = rgb2gray(img);
    end
    img = imresize(img, [256 256]);
    
    % compute dense features
    feats = conf.faceDescriptor.compute(img, 'doPooling', false, 'imName', images{i});
    num_feat = size(feats, 2);
    
    % subsample features
    feat_perm = randperm(num_feat);
    feat_perm = feat_perm(1:min(imgFeatLimit, num_feat));
    featImg{i} = feats(:, feat_perm);
    
end

% concat
featImg = cat(2, featImg{:});

% save descriptors
save(descPath, 'featImg');

end

