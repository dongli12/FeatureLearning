%  Copyright (c) 2014, Karen Simonyan
%  All rights reserved.
%  This code is made available under the terms of the BSD license (see COPYING file).

% conf = face_desc.config.feat_config('expName', expName, 'setName', setName, 'trainSettingName', trainSettingName);
conf = face_desc.config.feat_config();

database = load(conf.database.dbPath);

numSplits = 1;

imgList = database.images;

numImg = numel(imgList);

descDim = conf.descDim;
vocSize = conf.vocSize;

descName = conf.faceDescriptor.get_name();

if conf.compMirrorFeat
    descName = [descName '_mirr'];
end

% PCA & GMM paths
cbookDir = conf.exp.cbookDir;

dimredPath = sprintf('%s/PCA_%d.mat', cbookDir, descDim);
gmmPath = sprintf('%s/gmm_%d.mat', cbookDir, vocSize);

% load and set SIFT PCA projection
linTrans = load(dimredPath);        
conf.faceDescriptor.set_feat_proj(linTrans);

% load and set SIFT codebook
load(gmmPath, 'codebook');        
conf.faceDescriptor.set_codebook(codebook);

% FV dimensionality
featDim = conf.faceDescriptor.get_dim();
save_dir = ['../feat/' conf.setName '/'];
if ~exist(save_dir,'file')
    mkdir(save_dir);
end

for i = 1:numImg

    fprintf('Extract FV: %d/%d\n', i, numImg);
    
    save_file = [save_dir imgList{i} '.mat'];
    if ~exist(save_file, 'file')

        % load image 
        img = imread([conf.database.imDir imgList{i}]);
        
        ms = max(size(img,1),size(img,2));
        if ms > 800
            img = imresize(img,800/ms);
        end

        % compute descriptor
        fv_raw = conf.faceDescriptor.compute(img, 'doPooling', true, 'compMirrorFeat', conf.compMirrorFeat);
        save([save_dir imgList{i} '.mat'], 'fv_raw');
        
    end

end
    

